using TMPro;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class Enemy : MonoBehaviour {

	//Moving speed of enemy
	public float Speed = 5f;
    private int currentWaypoint = 0;
    private NavMeshAgent navAgent;
    void Start ()
	{
        navAgent = this.GetComponent<NavMeshAgent>();
        currentWaypoint = 0;
        navAgent.SetDestination(Waypoints.points[currentWaypoint].position);
        //Debug.Log(Waypoints.points[currentWaypoint].position.x);
        //Debug.Log(Waypoints.points[currentWaypoint].position.y);
        //Debug.Log(Waypoints.points[currentWaypoint].position.z);
        navAgent.stoppingDistance = 1f;
    }

	//TODO: Task 3 : Implement enemy moving logic.

	//[Optional] Utilize WayPoints and implement path-finding logic
	private void Update()
	{
        //transform.Translate(Vector3.up * Speed * Time.deltaTime);
        if (!navAgent.pathPending && navAgent.remainingDistance <= navAgent.stoppingDistance)
        {
            if (currentWaypoint >= Waypoints.points.Length - 1)
                Speed = 0;
            else
            {
                currentWaypoint = (currentWaypoint + 1 )% Waypoints.points.Length;
                navAgent.SetDestination(Waypoints.points[currentWaypoint].position);
            }
        }
        //Debug.Log(currentWaypoint);
        //navAgent.SetDestination(new Vector3(70, 2, -70));
    }

}
